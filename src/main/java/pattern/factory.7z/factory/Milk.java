package pattern.factory;

/**
 * @author : Lin Can
 * @description :  牛奶接口
 * @modified ：By
 * @date : 2018/6/18 21:34
 */
public interface Milk {
    Milk getMilk ();
}
